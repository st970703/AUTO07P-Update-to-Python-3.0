AUTO_DIR=~/src/auto/2000
PYTHONPATH=$AUTO_DIR/python:$AUTO_DIR/python/graphics:~/src/DataViewer/Python_interface/python_script:$AUTO_DIR/python/lib/Linux_OpenGL:$AUTO_DIR/python/lib/Linux_Mesa:.
DV=~/src/DataViewer
PATH=$PATH:$AUTO_DIR/bin
