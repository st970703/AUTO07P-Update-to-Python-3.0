#ifndef READFM_H
#define READFM_H

int readFM(const char* dFileName, const int size);

#endif

