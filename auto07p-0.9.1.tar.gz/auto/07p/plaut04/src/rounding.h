#ifndef ROUNDING_H
#define ROUNDING_H

double round(bool key, double value, int digits);
void rounding(double& amax, double& amin);

#endif

