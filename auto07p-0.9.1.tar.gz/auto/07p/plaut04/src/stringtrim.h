#ifndef STRINGTRIM_H
#define STRINGTRIM_H

#include <string>

void strlefttrim(std::string &str);
void strrighttrim(std::string &str);

#endif
