#ifndef CREATESPHERE_H
#define CREATESPHERE_H

#include <Inventor/nodes/SoSeparator.h>
SoSeparator *createSphere(float where[], float scaler);

#endif
